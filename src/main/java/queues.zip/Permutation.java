public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue r = new RandomizedQueue();
    }
}